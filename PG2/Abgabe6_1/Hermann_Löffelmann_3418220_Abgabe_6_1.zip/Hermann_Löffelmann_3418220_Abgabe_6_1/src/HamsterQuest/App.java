package HamsterQuest;

public class App {
	public static void main(String[] args) {
		Control gameControl = new Control();
		gameControl.StartGame();

	}
}