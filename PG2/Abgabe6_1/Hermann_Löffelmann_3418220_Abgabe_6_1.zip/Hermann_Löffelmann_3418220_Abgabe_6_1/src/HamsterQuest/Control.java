package HamsterQuest;

import java.util.Scanner;

public class Control {
	Map gameMap = new Map();
	Hamster playerHamster = new Hamster(gameMap, 6, 2, '>');

	Scanner sc = new Scanner(System.in);
	boolean running = true;

	public void StartGame() {
		IntroText();
		while (running) {
			gameMap.printMap();

			System.out.println("Input: ");

			String input = sc.nextLine();

			switch (input) {
			case "left":
				playerHamster.turnLeft();
				System.out.println("You turned left!");
				System.out.println("New direction " + playerHamster.getDirection());
				break;

			case "right":
				playerHamster.turnRight();
				System.out.println("You turned right!");
				System.out.println("New direction " + playerHamster.getDirection());
				break;

			case "move":
				System.out.println("You moved forward!");
				playerHamster.moveForward();
				break;

			case "exit":
				System.out.println("Bye!");
				running = false;
				break;

			case "corn":
				playerHamster.printSeedsEaten();
				break;

			default:
				System.out.println("!!!Invalid input!!!");
				break;
			}
			System.out.println("\n");
		}
		OutroText();
		sc.close();
	}

	public void IntroText() {
		System.out.println("\nWelcome to 'HamsterQuest' the hamster game\n");
		System.out.println("-------------------------------------------------");
		System.out.println("Controls: 'left' (rotate left), 'right' (rotate right),");
		System.out.println("'move' (move forward), 'exit' (exit the game),");
		System.out.println("'corn' (eaten corn)");
		System.out.println("-------------------------------------------------");

	}

	public void OutroText() {
		System.out.println("Thanks for playing!:)");
	}
}
