package Roulette;

import java.util.Scanner;

public class Roulette {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int playerCapital = 1000;
        int playerBet;
        int rouletteColor = -1; // Assigned to a random number
        int playersChosenNumber = -1; // Assigned to a random number

        System.out.println("\nWelcome to Roulette!");

        while (playerCapital > 0) {
            int randomRouletteNumber = (int) (Math.random() * 36 + 1);

            // Assign the numbers to a color
            switch (randomRouletteNumber) {
                case 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36: // Red
                    rouletteColor = 0;
                    break;

                case 2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35: // Black
                    rouletteColor = 1;
                    break;
            }

            System.out.println("\nPlease place your bet! (Current Capital: " + playerCapital + ")");

            // Check if player entered a valid bet
            while (true) {
                try {
                    playerBet = Integer.parseInt(scanner.next());
                    if (playerBet > playerCapital) {
                        System.out.println("Your capital is " + playerCapital + ", you can't use more than that!");
                        System.out.println("Enter a valid amount of money:");
                    } else if (playerBet <= 0) {
                        System.out.println("Bet must be greater than 0. Please enter a valid amount:");
                    } else {
                        break; 
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input. Please enter a valid integer.");
                   
                }
            }

            // Remove the player's bet from the capital/bank
            playerCapital -= playerBet;

            System.out.println("Make your guess! (Enter 'red', 'black', or a number between 0 to 36.)");

            String playersGuess = "";
            boolean validInput = false;
            boolean isNumber = false;

            // Check if player entered 'black', 'red' or a number between 0 and 36
            while (!validInput) {
                playersGuess = scanner.next();
                if (playersGuess.equalsIgnoreCase("red") || playersGuess.equalsIgnoreCase("black")) {
                    isNumber = false;
                    validInput = true;
                } else {
                    try {
                        playersChosenNumber = Integer.parseInt(playersGuess);
                        if (playersChosenNumber < 0 || playersChosenNumber > 36) {
                            System.out.println("Invalid Input. Please enter 'red', 'black' or a number between 0 and 36!");
                        } else {
                            isNumber = true;
                            validInput = true;
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid Input. Please enter 'red', 'black' or a number between 0 and 36!");
                    }
                }
            }

            // Check if player has won or not
            if (isNumber) {
                if (playersChosenNumber == randomRouletteNumber) {
                    System.out.println("Congratulations! You hit the jackpot!");
                    playerBet *= 35;
                    playerCapital += playerBet;
                } else {
                    System.out.println("Sorry, better luck next time!\n");
                }
            } else {
                if ((rouletteColor == 0 && playersGuess.equalsIgnoreCase("red")) ||
                        (rouletteColor == 1 && playersGuess.equalsIgnoreCase("black"))) {
                    System.out.println("Congratulations! You won!");
                    playerBet *= 2;
                    playerCapital += playerBet;
                } else {
                    System.out.println("Sorry, you lost this round.\n");
                }
            }

        }
        
        System.out.println("You have lost all your money! \nSee you next time!");
        scanner.close();
    }
}