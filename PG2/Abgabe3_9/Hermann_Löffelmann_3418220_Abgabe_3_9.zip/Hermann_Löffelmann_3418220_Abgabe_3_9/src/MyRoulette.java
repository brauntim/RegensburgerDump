import java.util.Random;
import java.util.Scanner;

// European style roulette
public class MyRoulette {
	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		Random random = new Random();

		// Setting starting bankroll to 1000€
		int playerBankroll = 1000;

		// Define arrays for red and black numbers
		int[] blackNumbers = { 1, 3, 5, 7, 9, 12, 14, 16, 18, 20, 22, 24, 26, 28, 29, 31, 33, 35 };
		int[] redNumbers = { 2, 4, 6, 8, 10, 11, 13, 15, 17, 19, 21, 23, 25, 27, 30, 32, 34, 36 };

		System.out.println("Welcome to MyRoulette. Good luck!");

		// Main game loop
		while (playerBankroll > 0) {
			// Generate a random winning number between 0 - 36
			int winningNumber = random.nextInt(37);

			// Overview of players current bankroll
			System.out.println("Your current Bankroll is " + playerBankroll + " Euro.");

			// Prompt the player to place a bet
			System.out.println("Faites vos jeux! (Make your bets)");
			int playerBet = sc.nextInt();

			// Validate the bet
			if (playerBet <= 0 || playerBet > playerBankroll) {
				System.out.println("Invalid bet amount. Please enter a positive amount within your bankroll.");
				continue;
			}

			// Subtract the bet from the player's bankroll
			playerBankroll -= playerBet;

			// Prompt the player to make a guess
			System.out.println("Make your guess! (Enter 'red', 'black', or a number between 0 to 36.)");
			String playerGuess = sc.next();

			// Checking player's guess
			switch (playerGuess) {
			case "black":
				if (numberIsBlack(winningNumber, blackNumbers)) {
					playerBankroll += 2 * playerBet;
					System.out.println("It's " + winningNumber + ". You've guessed right!");
				} else {
					System.out.println("Sorry, it's " + winningNumber + ". Better luck next time!");
				}
				break;

			case "red":
				if (numberIsRed(winningNumber, redNumbers)) {
					playerBankroll += 2 * playerBet;
					System.out.println("It's " + winningNumber + ". You've guessed right!");
				} else {
					System.out.println("Sorry, it's " + winningNumber + ". Better luck next time!");
				}
				break;

			default:
				try {
					int guessedNumber = Integer.parseInt(playerGuess);
					if (guessedNumber == winningNumber) {
						if (winningNumber == 0) {
							playerBankroll += 35 * playerBet;
						} else {
							playerBankroll += 2 * playerBet;
						}
						System.out.println("It's " + winningNumber + ". You've guessed right!");
					} else {
						System.out.println("Sorry, it's " + winningNumber + ". Better luck next time!");
					}
				} catch (NumberFormatException e) {
					System.out.println("Invalid input. Please enter 'red', 'black', or a number between 0 to 36. ");
				}
				break;
			}

			// Line break for better readability
			System.out.println("");
		}

		// Ending sequence
		System.out.println("You ran out of money!:(");
		sc.close();
	}

	// Method to check if number is black
	public static boolean numberIsBlack(int number, int[] blackNumbers) {
		for (int i = 0; i < blackNumbers.length; i++) {
			if (number == blackNumbers[i]) {
				return true;
			}
		}
		return false;
	}

	// Method to check if number is red
	public static boolean numberIsRed(int number, int[] redNumbers) {
		for (int i = 0; i < redNumbers.length; i++) {
			if (number == redNumbers[i]) {
				return true;
			}
		}
		return false;
	}
}
