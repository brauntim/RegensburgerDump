package HamsterQuest;

public class Hamster {
	private final Map gameMap;
	private int x;
	private int y;
	private char direction;
	private int seedsEaten;

	public Hamster(final Map gameMap, final int startY, final int startX, final char startDirection) {
		this.gameMap = gameMap;
		this.y = startY;
		this.x = startX;
		this.direction = startDirection;
		this.seedsEaten = 0;
	}

	// Hamster turns left
	public void turnLeft() {
		switch (direction) {
		case '^':
			direction = '<';
			break;
		case '<':
			direction = 'v';
			break;
		case 'v':
			direction = '>';
			break;
		case '>':
			direction = '^';
			break;
		}
		gameMap.updateDirection(y, x, direction);
	}

	// Hamster turns right
	public void turnRight() {
		switch (direction) {
		case '^':
			direction = '>';
			break;
		case '>':
			direction = 'v';
			break;
		case 'v':
			direction = '<';
			break;
		case '<':
			direction = '^';
			break;
		}
		gameMap.updateDirection(y, x, direction);
	}

	// Hamster moves forward
	public void moveForward() {
		int newY = y;
		int newX = x;

		switch (direction) {
		case '^':
			newY--;
			break;
		case '>':
			newX++;
			break;
		case 'v':
			newY++;
			break;
		case '<':
			newX--;
			break;
		}

		// Wall check
		if (gameMap.isWall(newY, newX)) {
			System.out.println("!!!You can not pass a wall!!!");
			return;
		}

		gameMap.clearLastPosition(y, x);

		y = newY;
		x = newX;

		// Corn check
		if (gameMap.isCorn(y, x)) {
			seedsEaten++;
			System.out.println("You ate a corn!");
		}

		gameMap.updateDirection(y, x, direction);
	}

	public void printSeedsEaten() {
		System.out.println("You have currently " + seedsEaten + " corn eaten.");
	}

	public char getDirection() {
		return direction;
	}
}