package HamsterQuest;

public class Map {
	private char[][] gameMap;

	public Map() {
		gameMap = new char[][] { { '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' },
				{ '#', ' ', ' ', ' ', ' ', ' ', '*', ' ', ' ', ' ', '#' },
				{ '#', ' ', ' ', ' ', '#', ' ', ' ', '*', ' ', ' ', '#' },
				{ '#', ' ', ' ', ' ', '*', '#', ' ', ' ', ' ', ' ', '#' },
				{ '#', ' ', ' ', ' ', '*', ' ', ' ', '#', '#', ' ', '#' },
				{ '#', '*', ' ', ' ', ' ', '#', '*', ' ', ' ', ' ', '#' },
				{ '#', ' ', '>', ' ', '*', '#', ' ', ' ', ' ', ' ', '#' },
				{ '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' }, };

	}

	// Print map
	public void printMap() {
		for (char[] i : gameMap) {
			System.out.println(new String(i));
		}
	}

	// Update direction
	public void updateDirection(int y, int x, char direction) {
		gameMap[y][x] = direction;
	}

	// CLear latest position
	public void clearLastPosition(int y, int x) {
		if (gameMap[y][x] == '#') {
			return;
		}
		gameMap[y][x] = ' ';
	}

	public boolean isWall(int y, int x) {
		return gameMap[y][x] == '#';
	}

	public boolean isCorn(int y, int x) {
		return gameMap[y][x] == '*';
	}
}
